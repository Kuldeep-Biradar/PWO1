from datetime import datetime
import altair as alt
from .stats import calculate_machine_stats
import pandas as pd

